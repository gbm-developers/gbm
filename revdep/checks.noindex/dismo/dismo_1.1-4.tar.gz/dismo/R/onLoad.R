
.onLoad <- function(libname, pkgname) { 
  .maxentRemoveTmpFiles()
}  
