library(testthat)
library(SDMPlay)

test_check("SDMPlay")
