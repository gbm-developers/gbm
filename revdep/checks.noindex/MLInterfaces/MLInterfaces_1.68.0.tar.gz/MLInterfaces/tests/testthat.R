library("testthat")
library("MLInterfaces")

test_check("MLInterfaces")
