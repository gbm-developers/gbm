randTrain = function(p, data) {
 if (p <= 0 | p >= 1) stop("p must be in (0,1)")
 p
 }
 
 
 
