library(testthat)
library(gbts)

test_check("gbts")
