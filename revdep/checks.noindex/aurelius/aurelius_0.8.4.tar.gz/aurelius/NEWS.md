# aurelius 0.8.4.9000

* Add typical R package structure including, README, NEWS, CONTRIBUTING, 
  .travis.yml, .Rbuildignore, and others) (@reportmort).
  
* Add functions to convert "glm" and "lm" S3 objects directly to PFA (@reportmort, #27, #28).

# aurelius 0.8.4

* Adopt Apache License 2.0