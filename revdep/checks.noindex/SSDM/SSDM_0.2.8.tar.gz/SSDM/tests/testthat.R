library(testthat)
library(SSDM)

test_check("SSDM")
