# test_that('load_occ function is correctly working', {
  # Env <- load_var(system.file("extdata",  package = 'SSDM'), verbose = F)
  # Occ <- load_occ(path = system.file("extdata",  package = 'SSDM'), Env,
                  # Xcol = 'LONGITUDE', Ycol = 'LATITUDE',
                  # file = 'Occurences.txt', verbose = F, sep = ',')
  # expect_is(Occ, "data.frame")
  # expect_equal(dim(Occ), c(28,3))
# })


