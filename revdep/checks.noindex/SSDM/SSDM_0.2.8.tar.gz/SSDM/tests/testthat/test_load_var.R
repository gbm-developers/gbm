# test_that('load_var function is correctly working', {
  # Env <- load_var(system.file("extdata",  package = 'SSDM'), verbose = F)
  # expect_is(Env, "RasterStack")
# })
