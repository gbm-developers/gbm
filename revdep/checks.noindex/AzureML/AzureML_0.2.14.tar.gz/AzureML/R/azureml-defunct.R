#' Deprecated functions
#' 
#' @rdname AzureML-deprecated
consumeDataframe <- function(){
  .Defunct("consume")
}

#' @rdname AzureML-deprecated
consumeFile <- function(){
  .Defunct("consume")
}

#' @rdname AzureML-deprecated
consumeLists <- function(){
  .Defunct("consume")
}

#' @rdname AzureML-deprecated
getEPDetails <- function(){
  .Defunct("endpoints")
}

#' @rdname AzureML-deprecated
getWSDetails <- function(){
  .Defunct("services")
}
