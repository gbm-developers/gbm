library(testthat)
library(SuperLearner)

test_check("SuperLearner")