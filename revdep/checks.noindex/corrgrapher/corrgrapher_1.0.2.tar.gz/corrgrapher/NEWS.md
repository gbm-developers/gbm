corrgrapher 1.0
----------------------------------------------------------------
* lowercase name of the package
* new generic function: print

