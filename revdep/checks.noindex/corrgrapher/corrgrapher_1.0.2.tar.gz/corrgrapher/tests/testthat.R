library(testthat)
library(corrgrapher)

test_check("corrgrapher")
