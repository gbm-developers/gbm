library(testthat)
library(triplot)

test_check("triplot")
