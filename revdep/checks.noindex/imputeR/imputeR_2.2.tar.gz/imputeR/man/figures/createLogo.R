library("hexSticker")

p <- "picture.png"

sticker(p, package="imputeR", p_family ="Arial", p_color = "#FFFFFF", h_fill = "#0F80FF", h_color ="#878787", p_size=8, s_x=1.1, s_y=.80, s_width=0.80, s_height=1,
        filename="imputeR-logo2.png")