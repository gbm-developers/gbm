library(testthat)
library(DALEXtra)

test_check("DALEXtra")
