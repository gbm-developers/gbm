library(testthat)
library(opera)
test_check("opera") 
