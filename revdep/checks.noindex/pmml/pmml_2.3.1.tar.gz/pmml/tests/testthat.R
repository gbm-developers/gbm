library(testthat)
library(pmml, quietly = T)

test_check("pmml")
