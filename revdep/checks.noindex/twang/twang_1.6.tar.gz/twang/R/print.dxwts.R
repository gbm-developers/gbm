print.dxwts <- function(x,...)
{
   print(x$summary.tab)
}