plot.dxwts <- function(x, plots="es", ...){
  pt1 <- diag.plot(x, plots, ...)
  return(pt1)	
}

