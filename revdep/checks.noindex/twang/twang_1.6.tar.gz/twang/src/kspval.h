/*
 *  kspval.h
 *  
 *
 *  Copied from R 2.15 source
 *
 */

#include <R.h>


void psmirnov2x(double *x, Sint *m, Sint *n);
