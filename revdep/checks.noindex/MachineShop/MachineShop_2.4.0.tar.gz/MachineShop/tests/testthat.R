library(testthat)
library(MachineShop)

test_check("MachineShop")
