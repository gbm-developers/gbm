#' Combine MachineShop Objects
#'
#' Combine one or more \pkg{MachineShop} objects of the same class.
#'
#' @name combine
#' @rdname combine-methods
#'
#' @param ... named or unnamed \link{calibration}, \link{confusion},
#'   \link{lift}, \link[=curves]{performance curve}, \link{summary}, or
#'   \link{resample} results.  Curves must have been generated with the same
#'   performance \link{metrics} and resamples with the same resampling
#'   \link[=controls]{control}.
#' @param e1,e2 objects.
#'
#' @return Object of the same class as the arguments.
#'
NULL


c.BinomialVariate <- function(...) {
  args <- list(...)
  if (all(map_logi(is, args, "BinomialVariate"))) {
    structure(do.call(rbind, args), class = "BinomialVariate")
  } else {
    NextMethod()
  }
}


#' @rdname combine-methods
#'
c.Calibration <- function(...) {
  args <- list(...)
  if (all(map_logi(is, args, "Calibration"))) {

    if (!identical_elements(args, function(x) x@smoothed)) {
      stop("Calibration arguments are a mix of smoothed and binned curves")
    }

    df <- do.call(append, set_model_names(args))
    Calibration(df, smoothed = args[[1]]@smoothed, .check = FALSE)

  } else {
    NextMethod()
  }
}


#' @rdname combine-methods
#'
c.ConfusionList <- function(...) {
  args <- list(...)
  is_valid <- function(x) is(x, "ConfusionList") || is(x, "ConfusionMatrix")
  if (all(map_logi(is_valid, args))) {

    conf_list <- list()
    for (i in seq(args)) {
      x <- args[[i]]
      if (is(x, "ConfusionMatrix")) x <- list("Model" = x)
      arg_name <- names(args)[i]
      if (!is.null(arg_name) && nzchar(arg_name)) {
        names(x) <- rep(arg_name, length(x))
      }
      conf_list <- c(conf_list, x)
    }
    names(conf_list) <- make.unique(names(conf_list))

    ConfusionList(conf_list)

  } else {
    NextMethod()
  }
}


#' @rdname combine-methods
#'
c.ConfusionMatrix <- function(...) {
  args <- list(...)
  args[[1]] <- ConfusionList(ListOf(args[1]))
  if (is.null(names(args)[1])) names(args)[1] <- "Model"
  do.call(c, args)
}


c.DiscreteVariate <- function(...) {
  args <- list(...)
  x <- NextMethod()
  class <- class(args[[1]])
  if (all(map_logi(is, args, class))) {
    new(class, x,
        min = min(map_num(slot, args, "min")),
        max = max(map_num(slot, args, "max")))
  } else {
    x
  }
}


#' @rdname combine-methods
#'
c.LiftCurve <- function(...) {
  NextMethod()
}


#' @rdname combine-methods
#'
c.ListOf <- function(...) {
  args <- list(...)
  class <- class(args[[1]][[1]])[1]
  is_valid <- function(x) {
    is(x, "ListOf") && is(x[[1]], class) && is(x[[1]], "vector")
  }
  if (all(map_logi(is_valid, args))) {
    x <- list()
    for (i in seq(args)) {
      name <- names(args)[i]
      if (!is.null(name) && nzchar(name)) {
        names(args[[i]]) <- rep(name, length(args[[i]]))
      }
      x <- c(x, args[[i]])
    }
    if (!is.null(names(x))) names(x) <- make.unique(names(x))
    ListOf(x)
  } else {
    NextMethod()
  }
}


c.Performance <- function(...) {
  args <- list(...)
  if (all(map_logi(is, args, "Performance"))) {
    if (length(args) > 1) {

      if (!identical_elements(args, function(x) dimnames(x)[1:2])) {
        stop("Performance objects have different row or column names")
      }

      Performance(abind(args, along = 3))

    } else {
      args[[1]]
    }
  } else {
    NextMethod()
  }
}


#' @rdname combine-methods
#'
c.PerformanceCurve <- function(...) {
  args <- list(...)
  class <- class(args[[1]])
  if (all(map_logi(is, args, class))) {

    if (!identical_elements(args, function(x) x@metrics)) {
      stop(class, " arguments have different metrics")
    }

    df <- do.call(append, set_model_names(args))
    do.call(class, list(df, metrics = args[[1]]@metrics, .check = FALSE))

  } else {
    NextMethod()
  }
}


#' @rdname combine-methods
#'
c.Resamples <- function(...) {
  args <- list(...)
  if (all(map_logi(is, args, "Resamples"))) {

    if (!identical_elements(args, function(x) x@control)) {
      stop("Resamples arguments have different control structures")
    }

    if (!identical_elements(args, function(x) x@strata)) {
      stop("Resamples arguments have different strata variables")
    }

    df <- do.call(append, set_model_names(args))
    Resamples(df, control = args[[1]]@control, strata = args[[1]]@strata,
              .check = FALSE)

  } else {
    NextMethod()
  }
}


c.SurvMatrix <- function(...) {
  args <- list(...)
  class <- class(args[[1]])
  if (all(map_logi(is, args, class))) {
    if (!identical_elements(args, function(x) x@times)) {
      stop(class, " arguments have different times")
    }
    new(class, do.call(rbind, args), times = args[[1]]@times)
  } else {
    NextMethod()
  }
}


#' @rdname combine-methods
#'
setMethod("+", c("SurvMatrix", "SurvMatrix"),
  function(e1, e2) {
    x <- callNextMethod()
    class <- class(e1)
    if (class(e2) == class && all(e1@times == e2@times)) {
      new(class, x, times = e1@times)
    } else x
  }
)
