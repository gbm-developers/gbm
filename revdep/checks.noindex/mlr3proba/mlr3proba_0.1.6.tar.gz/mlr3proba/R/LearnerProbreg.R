# LearnerProbreg = R6::R6Class("LearnerProbreg", inherit = Learner)
# LearnerProbreg$set("public","initialize", function(id, param_set = ParamSet$new(), param_vals = list(),
#                                                    predict_types = "prob", feature_types = character(),
#                                                    properties = character(), data_formats = "data.table",
#                                                    packages = character()){
#                              super$initialize(id = id, task_type = "probreg", param_set = param_set, param_vals = param_vals,
#                                               predict_types = predict_types, feature_types = feature_types, properties = properties,
#                                               data_formats = data_formats, packages = packages)
#                            })
