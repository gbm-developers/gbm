library(testthat)
library(OmicsMarkeR)

test_check("OmicsMarkeR")
