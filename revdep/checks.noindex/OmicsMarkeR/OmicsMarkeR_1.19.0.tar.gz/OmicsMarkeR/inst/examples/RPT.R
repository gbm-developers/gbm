# RPT demo
RPT(stability=0.85, performance=0.90, beta=1)
