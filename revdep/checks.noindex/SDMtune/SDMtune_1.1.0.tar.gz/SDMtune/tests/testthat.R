library(testthat)
library(SDMtune)

test_check("SDMtune")
